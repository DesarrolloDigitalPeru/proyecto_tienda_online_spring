-- MySQL dump 10.13  Distrib 8.0.45, for Linux (x86_64)
--
-- Host: localhost    Database: tiendaplazachina
-- ------------------------------------------------------
-- Server version	8.0.45

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `carrito`
--

DROP TABLE IF EXISTS `carrito`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `carrito` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cantidad` int NOT NULL,
  `producto_id` bigint NOT NULL,
  `usuario_id` bigint NOT NULL,
  `cupon_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKa66gl3j7wnlwyc1i7rj5cm163` (`producto_id`),
  KEY `FKbunaoq2qnb3gd29rcqv2e2dal` (`usuario_id`),
  KEY `FKp21ww2arblmpedj0u4irb4amj` (`cupon_id`),
  CONSTRAINT `FKa66gl3j7wnlwyc1i7rj5cm163` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`),
  CONSTRAINT `FKbunaoq2qnb3gd29rcqv2e2dal` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`),
  CONSTRAINT `FKp21ww2arblmpedj0u4irb4amj` FOREIGN KEY (`cupon_id`) REFERENCES `cupon` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carrito`
--

LOCK TABLES `carrito` WRITE;
/*!40000 ALTER TABLE `carrito` DISABLE KEYS */;
INSERT INTO `carrito` VALUES (1,2,3,2,NULL),(2,1,2,2,NULL),(3,1,4,2,NULL),(9,2,3,7,NULL),(10,2,4,7,NULL);
/*!40000 ALTER TABLE `carrito` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cupon`
--

DROP TABLE IF EXISTS `cupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cupon` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `activo` bit(1) NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `fecha_expiracion` datetime(6) DEFAULT NULL,
  `nombre_clave` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `porcentaje_descuento` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKew7qbumrfjr1wa97bvygmbc0a` (`nombre_clave`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cupon`
--

LOCK TABLES `cupon` WRITE;
/*!40000 ALTER TABLE `cupon` DISABLE KEYS */;
/*!40000 ALTER TABLE `cupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_orden`
--

DROP TABLE IF EXISTS `detalle_orden`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_orden` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cantidad` int NOT NULL,
  `descuento_unitario` decimal(10,2) DEFAULT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `orden_id` bigint NOT NULL,
  `producto_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  KEY `FKjme9iv95jkpacnpsvegpqhcq6` (`orden_id`),
  KEY `FKglw9feq38n5kihrdjwctg2lg0` (`producto_id`),
  CONSTRAINT `FKglw9feq38n5kihrdjwctg2lg0` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`),
  CONSTRAINT `FKjme9iv95jkpacnpsvegpqhcq6` FOREIGN KEY (`orden_id`) REFERENCES `ordenes` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_orden`
--

LOCK TABLES `detalle_orden` WRITE;
/*!40000 ALTER TABLE `detalle_orden` DISABLE KEYS */;
INSERT INTO `detalle_orden` VALUES (1,4,0.00,3.80,1,3),(2,2,0.00,12.50,1,4),(3,3,5.00,7.20,1,2),(4,1,0.00,6.50,1,6),(5,1,0.00,3.50,1,1);
/*!40000 ALTER TABLE `detalle_orden` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_venta`
--

DROP TABLE IF EXISTS `detalle_venta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_venta` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `cantidad` int NOT NULL,
  `precio_unitario` decimal(10,2) NOT NULL,
  `pago_id` bigint NOT NULL,
  `producto_id` bigint NOT NULL,
  `cupon_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK8gcwojgg489i43ub0tfvi8smx` (`pago_id`),
  KEY `FKdn5t1y68ckfy82hqxs0lmi9e` (`producto_id`),
  KEY `FKmmfpis369u8jq7mn08d441dv2` (`cupon_id`),
  CONSTRAINT `FK8gcwojgg489i43ub0tfvi8smx` FOREIGN KEY (`pago_id`) REFERENCES `pagos` (`id`),
  CONSTRAINT `FKdn5t1y68ckfy82hqxs0lmi9e` FOREIGN KEY (`producto_id`) REFERENCES `productos` (`id`),
  CONSTRAINT `FKmmfpis369u8jq7mn08d441dv2` FOREIGN KEY (`cupon_id`) REFERENCES `cupon` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_venta`
--

LOCK TABLES `detalle_venta` WRITE;
/*!40000 ALTER TABLE `detalle_venta` DISABLE KEYS */;
INSERT INTO `detalle_venta` VALUES (1,1,3.50,1,1,NULL);
/*!40000 ALTER TABLE `detalle_venta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ordenes`
--

DROP TABLE IF EXISTS `ordenes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `ordenes` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `descuento_cupon` decimal(10,2) DEFAULT NULL,
  `estado` enum('cancelada','confirmada','pagada','pendiente') COLLATE utf8mb4_general_ci NOT NULL,
  `fecha` datetime(6) NOT NULL,
  `notas` text COLLATE utf8mb4_general_ci,
  `numero_orden` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT NULL,
  `total_descuento_productos` decimal(10,2) DEFAULT NULL,
  `cupon_id` bigint DEFAULT NULL,
  `usuario_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKkquinjwfjisvx0u6jj9flgt3g` (`numero_orden`),
  KEY `FK7246bw3aw2fryg5o7kxoyroaq` (`cupon_id`),
  KEY `FKsqu43gsd6mtx7b1siww96324` (`usuario_id`),
  CONSTRAINT `FK7246bw3aw2fryg5o7kxoyroaq` FOREIGN KEY (`cupon_id`) REFERENCES `cupon` (`id`),
  CONSTRAINT `FKsqu43gsd6mtx7b1siww96324` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ordenes`
--

LOCK TABLES `ordenes` WRITE;
/*!40000 ALTER TABLE `ordenes` DISABLE KEYS */;
INSERT INTO `ordenes` VALUES (1,0.00,'pendiente','2026-03-01 17:49:47.960298',NULL,'ORD-20260301224947-09930',71.80,70.72,1.08,NULL,7);
/*!40000 ALTER TABLE `ordenes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `detalles_venta_json` text COLLATE utf8mb4_general_ci,
  `estado` enum('completado','pendiente','rechazado') COLLATE utf8mb4_general_ci NOT NULL,
  `fecha_venta` datetime(6) NOT NULL,
  `metodo_pago` enum('efectivo','paypal','plin','tarjeta','transferencia','yape') COLLATE utf8mb4_general_ci NOT NULL,
  `monto_pagado` decimal(10,2) NOT NULL,
  `numero_boleta` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `usuario_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKnl6h8mol779toeaaa675m2uf1` (`numero_boleta`),
  KEY `FKnv3skx0qnku57yljq0bu88oot` (`usuario_id`),
  CONSTRAINT `FKnv3skx0qnku57yljq0bu88oot` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (1,NULL,'completado','2026-02-09 19:33:13.000000','efectivo',3.50,'001',2);
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `categoria` enum('ABARROTES','BEBES_MATERNIDAD','BEBIDAS','BELLEZA','COCINA_HOGAR','ELECTRONICA','HIGIENE_PERSONAL','LIMPIEZA_HOGAR','MANUALIDADES','ROPA_ACCESORIOS','SNACKS_GOLOSINAS','TECNOLOGIA') COLLATE utf8mb4_general_ci NOT NULL,
  `descripcion` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `descuento` decimal(5,2) DEFAULT NULL,
  `disponible` bit(1) NOT NULL,
  `imagen_url` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `marca` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `precio` decimal(10,2) NOT NULL,
  `promocion` bit(1) NOT NULL,
  `stock` int NOT NULL,
  `unidad_medida` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `genero` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `talla` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  `tela` varchar(255) COLLATE utf8mb4_general_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,'ABARROTES','Arroz blanco de grano largo 1kg',0.00,_binary '','https://www.supereldesafio.com.ar/wp-content/uploads/2020/09/754-MOLTO-ARROZ-LARGO-FINO-1-KG-1-1-1536x1536.png','Molino Real','Arroz Largo Fino',3.50,_binary '',100,'kg',NULL,NULL,NULL),(2,'ABARROTES','Aceite puro de girasol 1 Litro',5.00,_binary '','https://media.falabella.com/tottusPE/42757359_2/w=800,h=800,fit=pad','Primor','Aceite Vegetal',7.20,_binary '\0',44,'bot',NULL,NULL,NULL),(3,'ABARROTES','Leche entera enriquecida 400g',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR_4CLQncej7XDkWtOIohTbAW8nIS684q78Uw&s','Gloria','Leche Evaporada',3.80,_binary '\0',198,'tarro',NULL,NULL,NULL),(4,'LIMPIEZA_HOGAR','Limpieza profunda aroma floral',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRvgAbKNuKk4abG8bRWm1B3eZXjW8JHSfhmAA&s','Ariel','Detergente Polvo',12.50,_binary '\0',75,'kg',NULL,NULL,NULL),(5,'ABARROTES','Fideos de sémola de trigo duro 450g',0.00,_binary '','https://metroio.vtexassets.com/arquivos/ids/405515/Fideo-Spaghetti-Don-Vittorio-950g-1-299745267.jpg?v=638181138612730000','Don Vittorio','Fideos Tallarín',3.20,_binary '\0',150,'paquete',NULL,NULL,NULL),(6,'ABARROTES','Trozos de atún en aceite vegetal 170g',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRn9_8onSDXeLvWGDUSiNBlQJ0miZfb1oUi3Q&s','Primor','Atún en Trozos',6.50,_binary '\0',200,'lata',NULL,NULL,NULL),(7,'ABARROTES','Lentejas seleccionadas de rápida cocción 500g',5.00,_binary '','https://plazavea.vteximg.com.br/arquivos/ids/27552452-512-512/995413.jpg','Costeño','Lenteja Bebé',5.80,_binary '',87,'bolsa',NULL,NULL,NULL),(8,'ABARROTES','Sal de mesa refinada 1kg',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRfZLgnFUw2NA-k6haOJ4_Z1uyH3rREk9YslQ&s','Lobos','Sal Yodada',1.50,_binary '\0',300,'bolsa',NULL,NULL,NULL),(9,'ABARROTES','Mayonesa clásica cremosa 190g',0.00,_binary '','https://vegaperu.vtexassets.com/arquivos/ids/159523/7750243046114.jpg?v=637835757917300000','Alacena','Mayonesa Doypack',4.90,_binary '\0',120,'unidad',NULL,NULL,NULL),(10,'HIGIENE_PERSONAL','Protección 48h Invisible for Black & White',10.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQKYy624b3Ak54CJwGiDPvlUEJoudHsKAPDLg&s','Nivea','Desodorante Roll-on',12.50,_binary '',85,'unidad',NULL,NULL,NULL),(11,'HIGIENE_PERSONAL','Enjuague Cool Mint protección total 500ml',0.00,_binary '','https://leonisa.pe/cdn/shop/products/LT100_SIN_1200X1500_1_960x.jpg?v=1666379371','Listerine','Enjuague Bucal',19.90,_binary '\0',48,'botella',NULL,NULL,NULL),(12,'HIGIENE_PERSONAL','Crema corporal hidratación profunda 400ml',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ_B4ObC3VlfQa61MyPh1r636t_BbTcHPZL9Q&s','Lubriderm','Crema Humectante',28.00,_binary '\0',40,'botella',NULL,NULL,NULL),(13,'HIGIENE_PERSONAL','Máquina de afeitar 3 hojas pack x2',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTloY6MpGxD54YaA-ELXCCNGv0bB5wLc-0R7w&s','Gillette','Afeitadora Desechable',9.50,_binary '\0',110,'paquete',NULL,NULL,NULL),(14,'HIGIENE_PERSONAL','Fotoprotector toque seco SPF 50+ 50ml',15.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRk9lGVG1R2irbyE5xqeAczXA7C3dsvmK0lPA&s','Eucerin','Protector Solar',85.00,_binary '',25,'unidad',NULL,NULL,NULL),(15,'BEBIDAS','Bebida gasificada sabor original 1.0L',0.00,_binary '','https://www.donbelisario.com.pe/media/catalog/product/2/1/2146463136.png?optimize=medium&bg-color=255,255,255&fit=bounds&height=700&width=700&canvas=700:700&format=jpeg','Inca Kola','Gaseosa Amarilla',8.50,_binary '\0',178,'botella',NULL,NULL,NULL),(16,'BEBIDAS','Bebida energética taurina y cafeína 250ml',0.00,_binary '','https://oechsle.vteximg.com.br/arquivos/ids/1352052-1000-1000/image-909dc2275de5486fbaf16f346b37fabf.jpg?v=637494728345970000','Red Bull','Energizante Lata',7.50,_binary '\0',250,'lata',NULL,NULL,NULL),(17,'BEBIDAS','Yogurt parcial descatado con trozos 1kg',0.00,_binary '','https://vegaperu.vtexassets.com/arquivos/ids/159174/7750151005548.jpg?v=637660223633330000','Laive','Yogurt Fresa',6.20,_binary '\0',70,'botella',NULL,NULL,NULL),(18,'BEBIDAS','Cerveza tipo malta botella 330ml',0.00,_binary '','https://sumon.com.pe/wp-content/uploads/2024/10/cerveza-cusquena-negra-botella-310ml.webp','Cusqueña','Cerveza Negra',5.50,_binary '\0',119,'unidad',NULL,NULL,NULL),(19,'BEBIDAS','Agua mineral gasificada 600ml',0.00,_binary '','https://socialdrinks.pe/wp-content/uploads/2022/04/1313_BE00000051.jpeg','San Luis','Agua con Gas',2.20,_binary '\0',200,'botella',NULL,NULL,NULL),(20,'SNACKS_GOLOSINAS','Extruido de maíz sabor queso 150g',0.00,_binary '','https://aceleralastatic.nyc3.cdn.digitaloceanspaces.com/files/uploads/1499/1603484937-76-cheese-tris-jpg.jpg','Frito Lay','Cheese Tris',3.50,_binary '\0',140,'bolsa',NULL,NULL,NULL),(21,'SNACKS_GOLOSINAS','Chocolate con leche relleno de crema',0.00,_binary '','https://oechsle.vteximg.com.br/arquivos/ids/1890419-1000-1000/image-72b7ec8390a9424a964fcca24d929b72.jpg?v=637495394441230000','DOnofrio','Chocolate Triangulo',1.50,_binary '\0',300,'unidad',NULL,NULL,NULL),(22,'SNACKS_GOLOSINAS','Galleta salada clásica pack familiar',5.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRE16YIo6RmodDZJEQXrAj2H6IN10BdYbcqwg&s','Field','Galleta Soda',4.50,_binary '\0',96,'paquete',NULL,NULL,NULL),(23,'SNACKS_GOLOSINAS','Barra de cereal con chispas de chocolate',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQzYhTktXV5eYDdlDD8C8HZRMgyzzr_WWaX3w&s','Angel','Cereal Bar',1.20,_binary '\0',250,'unidad',NULL,NULL,NULL),(24,'SNACKS_GOLOSINAS','Papas fritas sabor picante intenso 45g',0.00,_binary '','https://m.media-amazon.com/images/I/71ACTLq+c+L._SL1500_.jpg','Pringles','Papas Picantes',6.90,_binary '\0',60,'lata',NULL,NULL,NULL),(25,'TECNOLOGIA','Mouse USB ergonómico cable 1.5m',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSlJ_hFgbvoM6-Zxl25yJzz5hAKDnx7CaScNg&s','Genius','Mouse Óptico',25.00,_binary '\0',40,'unidad',NULL,NULL,NULL),(26,'TECNOLOGIA','Teclado USB resistente a derrames',10.00,_binary '','https://media.falabella.com/falabellaPE/140857295_01/w=800,h=800,fit=pad','Logitech','Teclado Simple',45.00,_binary '',25,'unidad',NULL,NULL,NULL),(27,'TECNOLOGIA','Cable HDMI 4K alta velocidad',0.00,_binary '','https://oechsle.vteximg.com.br/arquivos/ids/3115472/image-1613de1a769449be8e49d40210e20aec.jpg?v=637494631512000000','Halion','Cable HDMI 2m',15.00,_binary '\0',55,'unidad',NULL,NULL,NULL),(28,'TECNOLOGIA','Pilas AA larga duración pack x4',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTdabEYolGxM-YZR24n07tGUpC642eMpJgumg&s','Duracell','Pila Alcalina AA',18.00,_binary '\0',90,'paquete',NULL,NULL,NULL),(29,'TECNOLOGIA','Adaptador de pared carga rápida 2.1A',0.00,_binary '','https://plazavea.vteximg.com.br/arquivos/ids/29211280-418-418/image-09030da0233f4a868469a75819379a62.jpg','Sony','Cargador USB',35.00,_binary '\0',30,'unidad',NULL,NULL,NULL),(30,'LIMPIEZA_HOGAR','Limpiador de cristales gatillo 500ml',0.00,_binary '','https://i5.walmartimages.com/asr/56234dc0-3ea8-4ed1-91cc-f45108c3c83a.3c949d2a46c81d8f967d3aead70cf194.jpeg','Windex','Limpia Vidrios',8.50,_binary '\0',65,'botella',NULL,NULL,NULL),(31,'LIMPIEZA_HOGAR','Cera líquida roja para pisos 1L',0.00,_binary '','https://plazavea.vteximg.com.br/arquivos/ids/27525125-512-512/20145794.jpg','Tekno','Cera para Piso',12.00,_binary '\0',40,'botella',NULL,NULL,NULL),(32,'LIMPIEZA_HOGAR','Elimina 99.9% de gérmenes 400ml',10.00,_binary '','https://plazavea.vteximg.com.br/arquivos/ids/25019661-418-418/20202155.jpg','Lysol','Desinfectante Spray',22.00,_binary '',55,'lata',NULL,NULL,NULL),(33,'LIMPIEZA_HOGAR','Potente limpiador para inodoros 450ml',0.00,_binary '','https://media.falabella.com/sodimacPE/4087674_01/w=1500,h=1500,fit=cover','Harpic','Quita Sarro',7.50,_binary '\0',80,'botella',NULL,NULL,NULL),(34,'LIMPIEZA_HOGAR','Limpiador de madera brillo natural 400ml',0.00,_binary '','https://i5-mx.walmartimages.com/gr/images/product-images/img_large/00779052001201L.jpg','Pledge','Lustramuebles',14.50,_binary '\0',45,'lata',NULL,NULL,NULL),(35,'BELLEZA','Delineador líquido punta plumón',0.00,_binary '','https://deliperu.shop/unique-cusco/ta/delineador-liquido-punta-plumon-negro-m20-1-960-720.jpeg','Unique','Delineador Negro',28.00,_binary '\0',60,'unidad',NULL,NULL,NULL),(36,'BELLEZA','Paleta de 12 colores tierra mate',20.00,_binary '','https://ibella.pe/cdn/shop/products/REVL-SOOJ-PHOTOREADYPRIMERSHADOWSPARKLE-RUSTIC.png?v=1713994764','Revlon','Sombras Ojos',45.00,_binary '',15,'unidad',NULL,NULL,NULL),(37,'BELLEZA','Removedor de esmalte sin acetona 120ml',0.00,_binary '','https://wongfood.vtexassets.com/arquivos/ids/481074-500-auto?v=637695828745070000&width=500&height=auto&aspect=true','Cutter','Quitaesmalte',6.50,_binary '\0',90,'frasco',NULL,NULL,NULL),(38,'BELLEZA','Brocha kabuki para base líquida',0.00,_binary '','https://aruma.vtexassets.com/arquivos/ids/193654/1024624.jpg?v=638465487193530000','Real Techniques','Brocha Maquillaje',35.00,_binary '\0',30,'unidad',NULL,NULL,NULL),(39,'BELLEZA','Mascarilla hidratante de tela ácido hialurónico',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTydwxNnt_1--t2UQJXl5JQrhiKQbSU5Mbw2g&s','Garnier','Mascarilla Facial',9.90,_binary '\0',100,'unidad',NULL,NULL,NULL),(40,'MANUALIDADES','Pliego de cartulina 180g pack x10',0.00,_binary '','https://chang.pe/wp-content/uploads/2023/12/e59541ed-53e9-48ba-a1f1-1ee3977bb272.jpg','Artesco','Cartulina de Colores',8.50,_binary '\0',147,'paquete',NULL,NULL,NULL),(41,'MANUALIDADES','Pegamento en barra 40g no tóxico',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTwbpafCSIMM4QRRwak75PSEFTLtupgJp-eA&s','UHU','Goma en Barra',5.50,_binary '\0',200,'unidad',NULL,NULL,NULL),(42,'MANUALIDADES','Barras de plastilina moldeable escolar',0.00,_binary '','https://production-tailoy-repo-magento-statics.s3.amazonaws.com/imagenes/872x872/productos/i/p/l/plastilina-jumbo-faber-castell-xl-estuche-x-12-und-65642-default-1.jpg','Faber-Castell','Plastilina 12 Colores',6.90,_binary '\0',120,'caja',NULL,NULL,NULL),(43,'MANUALIDADES','Regla de plástico transparente biselada',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQR3lILMrSZFwBkL0pHnrzO23pRulkI9CjIVg&s','Maped','Regla 30cm',2.00,_binary '\0',300,'unidad',NULL,NULL,NULL),(44,'MANUALIDADES','Estuche de acuarelas con pincel incluido',0.00,_binary '','https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTqnBuSEh3gAnRQ-2i5MQp4eugkVXJZjD-dkg&s','Pelikan','Acuarelas x12',14.00,_binary '\0',40,'caja',NULL,NULL,NULL);
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `apellido` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `contrasena` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `correo` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `dni` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `nombre` varchar(255) COLLATE utf8mb4_general_ci NOT NULL,
  `tipo` enum('admin','usuario') COLLATE utf8mb4_general_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKcdmw5hxlfj78uf4997i3qyyw5` (`correo`),
  UNIQUE KEY `UKggd9d47p8x7m0ajavk1ayuyqs` (`dni`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Mendoza','$2a$10$6BuSsZsB3atXNBo3TJYhFer7C2ZuD1d1WD9aWms6LfxhZI2bQy9..','miguel@gmail.com','41057604','miguel','usuario'),(2,'Castro','$2a$10$7MIG10HKusIj5.TH6vaIN.dAFXuVWToMZkFH6aVQGQzjFFVH8feWa','juan@gmail.com','123456789','Juan','usuario'),(3,'Castro','$2a$10$iNEqvon9YPLYUj.o4ewNTeIyFC9Z953DmZkXS402Vd5ttBM.ma5jC','mhmt@gmail.com','45678914','Miguel','admin'),(4,'Cruz','$2a$10$qIPk0pOcKUTGMMl6yVZcEur8ygMzZmsDJ3HovaDpaOkd753abEkjK','angel@gmail.com','23232323','Angel','usuario'),(5,'Perez','$2a$10$BS0NCGjPnOP6FuONM8bUpO.sjVGjkXmkUn5wYemYI2bOAMl47H3Gu','edu@gmail.com','78951236','Eduardo','admin'),(6,'Mendoza','$2a$10$ZBpVKCXZW03iifcAoHB4kugdtPoXUER9AsSYZhJC2bfDpDb5br7J.','mendozat@plazachina.com','62944056','Miguel','admin'),(7,'cueva','$2a$10$Y.lyweVEk/HxSIC49LHNdOtzTHlhEFRwlnlKENtJxMNmEaZeT8Vgu','alex@gmail.com','124578963','alex','usuario');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-02  4:14:29
